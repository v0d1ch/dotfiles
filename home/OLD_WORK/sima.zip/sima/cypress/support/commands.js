Cypress.Commands.add("login", () => {
cy.visit(Cypress.env('base_url') + '/session/wipe') 
cy.visit(Cypress.env('base_url') + '/login')  
cy.wait(3000)
cy.get('#email').type(Cypress.env('default_user_email'))
cy.get('#password').type(Cypress.env('default_user_password'))
cy.get(".login").click()
cy.wait(3000)
    
});