describe('jobSearch_spec', () => {
   beforeEach(() => {
      cy.login();
   })
   it('find first input', () => {
      cy.get('.flex').find('input').type('test')
      cy.wait(5000)
      cy.get('.search-results').should('be.visible')
   })
})
