Cypress.on('uncaught:exception', (err, runnable) => {
    return false
})
describe('menuDropdown', () => {
    beforeEach(() => {
        cy.login();
      })
    it('find dropdown menu', () => {
       cy.visit(Cypress.env('base_url')) 
       cy.get('.user-menu').click({force:true})
       cy.contains('Admin').click({force:true})
       cy.contains('Unpaid Trial').should('be.visible')
       cy.contains('Paid Trial').should('be.visible')
       cy.contains('Lapsed').should('be.visible')
       cy.contains('Paid').should('be.visible')
       cy.contains('Feed Settings').click({force:true})
       cy.get('.ember-view [type="checkbox"]').then(function($ch){
        expect($ch).to.have.length(14)
       })
    })
})