Cypress.on('uncaught:exception', (err, runnable) => {
    return false
})
describe('Logout Menu', () => {
    beforeEach(() => {
        cy.login();
    })
    it('Logout', () => {
        cy.visit(Cypress.env('base_url')) 
        cy.wait(3000)
        cy.get('.user-menu').click({force:true})
        cy.contains('Log out').click({force:true})
        cy.request('https://betterteam.com').should((response) => {
            expect(response.status).to.eq(200)
        })
    })
})