Cypress.on('uncaught:exception', (err, runnable) => {
  return false
})
describe('User is able to login', () => {
    it('visit login', () => {
        cy.visit(Cypress.env('base_url') + '/login')  
        cy.contains('Great to see you again!')
        cy.get('#email').should('be.visible')
        cy.get('#password').should('be.visible')
        cy.contains('Sign up for free')
        cy.get('.underline').should('have.attr', 'href').then((href) => {
            expect(href).to.equal(Cypress.env('base_url') + '/signup')
        })
    })
})
