describe('homepage test', () => {
  it('visit homepage', () => {
    cy.visit(Cypress.env('base_url'))
    
    cy.url().should('include', '/signup')
    cy.contains('Post Your Job to 100+ Job Sites')
  
  })

  it('make sure signup form is visible', () => {
    cy.visit(Cypress.env('base_url'))
    cy.get('#name').should('be.visible')
    cy.get('#organization').should('be.visible')
    cy.get('#email').should('be.visible')
    cy.get('#company-website').should('be.visible')
    cy.get('#password').should('be.visible')
    cy.get('#local').should('be.visible')
    cy.get('.underline').should('be.visible')
    cy.contains('Log in here') 
    cy.get('.underline').should('have.attr', 'href').then((href) => {
      expect(href).to.equal(Cypress.env('base_url') + '/login')
    })
  }) 
})