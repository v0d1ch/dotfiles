describe('Billing Support', () => {
  beforeEach(() => {
    cy.login();
  })
  it('find Billing Support Page', () => {
    cy.visit(Cypress.env('base_url')) 
    cy.wait(3000)
    cy.get('.user-menu').click({force:true})
    cy.contains('Billing').click({force:true})
  })
})