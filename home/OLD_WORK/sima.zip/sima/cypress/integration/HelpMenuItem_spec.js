Cypress.on('uncaught:exception', (err, runnable) => {
    return false
})
describe('Companies', () => {
    beforeEach(() => {
        cy.login();
    })
    it('find Companies', () => {
        cy.visit(Cypress.env('base_url')) 
        cy.get('.user-menu').click({force:true})
        cy.contains('Help').click({force:true})
        
        })
    })

