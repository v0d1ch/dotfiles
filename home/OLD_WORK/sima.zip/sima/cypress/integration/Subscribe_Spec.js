Cypress.on('uncaught:exception', (err, runnable) => {
  return false
})

describe('User is able subscribe and then change subscription', () => {
  beforeEach(() => {
    cy.login();
  })
  it('User logs in and visits subscription page', () => {
    cy.contains("Showing")
    cy.visit(Cypress.env('base_url') + '/subscribe')
    cy.contains("Go to Billing")
  })
})
