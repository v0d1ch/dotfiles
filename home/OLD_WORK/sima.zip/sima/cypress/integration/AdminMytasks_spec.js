Cypress.on('uncaught:exception', (err, runnable) => {
    return false
})
describe('check if admin menu works', () => {
    beforeEach(() => {
        cy.login();
    })
    it('curation pages and admin/companies give 200', () => {
       cy.request(Cypress.env('base_url') + '/curation/claimed/mine').should((response) => {
            expect(response.status).to.eq(200)
        })
        cy.request(Cypress.env('base_url') + '/curation/claimed').should((response) => {
            expect(response.status).to.eq(200)
        })
        cy.request(Cypress.env('base_url') + '/admin/companies').should((response) => {
            expect(response.status).to.eq(200)
        })
    })
    
})
