Cypress.on('uncaught:exception', (err, runnable) => {
  return false
})
describe('should find admin menu', () => {
  beforeEach(() => {
    cy.login();
  })
  it('find admin menu', () => {
    cy.visit(Cypress.env('base_url')) 
    cy.get('.user-menu').click({force:true})
    cy.contains('Admin').click({force:true})
    cy.contains('Admin').should('be.visible')
    cy.contains('My Tasks').should('be.visible')
    cy.contains('Unfinished Tasks').should('be.visible')
    cy.contains('Companies').should('be.visible')        
  })
})
