Cypress.on('uncaught:exception', (err, runnable) => {
    return false
     })
describe('Companies', () => {
    beforeEach(() => {
        cy.login();
      })
    it('find Companies', () => {
       cy.visit(Cypress.env('base_url')) 
       cy.get('.user-menu').click({force:true})
       cy.contains('Admin').click({force:true})
       cy.contains('Companies').click({force:true})
       cy.get('[name="companyName"]').type('Betterteam').type('{enter}')
       cy.get('.clearfix').find('.w-50-l').its('length').should('be.gte',1)
       
       
    })
})