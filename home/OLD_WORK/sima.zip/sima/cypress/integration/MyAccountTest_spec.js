Cypress.on('uncaught:exception', (err, runnable) => {
    return false
     })
describe('Companies', () => {
    beforeEach(() => {
       cy.login();
    })
    it('find Companies', () => {
       cy.visit(Cypress.env('base_url')) 
       cy.get('.user-menu').click({force:true})
       cy.contains('My account').click({force:true})
       cy.contains('Edit Name').click({force:true})
       cy.get('.mb0').clear().type('test')
       cy.contains('Save').click({force:true})
       cy.contains('test')
       cy.contains('Edit Name').click({force:true})
       cy.get('.mb0').clear().type('Sinisa Bogicevic')
       cy.wait(3000)
       cy.contains('Save').click({force:true})
    })
})