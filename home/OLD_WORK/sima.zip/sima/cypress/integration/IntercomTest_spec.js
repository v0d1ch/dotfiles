/*Cypress.on('uncaught:exception', (err, runnable) => {
    return false
})
describe('Intercom test', () => {
  beforeEach(() => {
    cy.login();
  })
  it('find Intercom', () => {
    cy.get('.intercom-launcher').click().next()
    cy.get('#intercom-container')
  })
})*/
