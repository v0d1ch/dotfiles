Cypress.on('uncaught:exception', (err, runnable) => {
    return false
    })
describe('Companies', () => {
  beforeEach(() => {
    cy.login();
  })
  it('find Companies', () => {
    cy.get('.user-menu').click()
    cy.wait(3000)
    cy.contains('Admin').click({force:true})
    cy.contains('Companies').click({force:true})
    cy.get('[name="companyName"]').type('Betterteam').type('{enter}')
    cy.wait(3000)
    cy.get('.clearfix').find('.w-50-l').its('length').should('be.gte',1)
    cy.get('.w-50-l:nth-child(2)').contains('Details').click()
    cy.contains('Company Verified')
    cy.contains('Trusted').click({force:true})
    cy.contains('Feed Settings')
    cy.get('[name="companyName"]').clear().type('Betterteam')
    cy.get('[name="companySubdomain"]').clear().type('car eers')
    cy.get('[name="companyDescription"]')
    cy.get('[name="companyWebsiteOriginal"]')
    cy.contains('Update Company Details').click()
    cy.contains('Subdomain input is not valid!')
    cy.contains('Back').click({force:true})
    cy.wait(3000)
    cy.contains('Refresh Subscription Details')
    cy.contains('Cancel Subscription')
    cy.get('[name="email"]').clear().type(Cypress.env('default_user_email'))
    cy.contains('Impersonate Manager').click({force:true})
  })
})
