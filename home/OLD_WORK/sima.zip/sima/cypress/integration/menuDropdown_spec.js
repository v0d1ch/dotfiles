describe('menuDropdown', () => {
  beforeEach(() => {
    cy.login();
  })
    it('find dropdown menu', () => {
    cy.visit(Cypress.env('base_url')) 
    cy.get('.user-menu').click({force:true})
    cy.get('ul.vertical').should('be.visible')
    cy.get('ul.vertical>li').then(function($lis){
    expect($lis).to.have.length(7)
    expect($lis.eq(0)).to.contain('Sinisa')
    expect($lis.eq(1)).to.contain('My account')
    expect($lis.eq(3)).to.contain('Career page designer')
    expect($lis.eq(4)).to.contain('Help')
    expect($lis.eq(5)).to.contain('Admin')
    expect($lis.eq(6)).to.contain('Log out')
        
    })
  })
})
